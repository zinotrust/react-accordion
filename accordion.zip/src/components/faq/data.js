export const questions = [
  {
    id: 1,
    title: "Can I learn ReactJS?",
    answer: "Yes, you can learn ReactJS at ZinoTrustAcademy.com",
  },
  {
    id: 2,
    title: "How can I get started with SocialX?",
    answer:
      "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Asperiores quae nisi impedit earum? Molestias eum laborum distinctio iste dolore! Deserunt cum veritatis laboriosam nihil, beatae voluptate sint officia obcaecati quae.",
  },
  {
    id: 3,
    title: "Is there a refund policy?",
    answer:
      "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Asperiores quae nisi impedit earum? Molestias eum laborum distinctio iste dolore! Deserunt cum veritatis laboriosam nihil, beatae voluptate sint officia obcaecati quae.",
  },
];
