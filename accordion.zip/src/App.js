import "./App.scss";
import Faq from "./components/faq/Faq";

function App() {
  return (
    <div>
      <Faq />
    </div>
  );
}

export default App;
